package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JOptionPane;

import tela.BotaoCarta;
import tela.TelaJogo;
import unbbayes.io.NetIO;
import unbbayes.prs.bn.ProbabilisticNetwork;
import unbbayes.prs.bn.ProbabilisticNode;
import estrutura.Deck;
import estrutura.PokerHand;

/*
 * Created on 07/03/2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author Particular
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ControladorJogo {
   private PokerHand maoMinha, maoOponente;
   private TelaJogo telaJogo;
   private Deck baralho;
   private int betHand;
   private int numTrocas[] = new int[2];
   private final int MAXBETHANDS = 2;
   private ProbabilisticNetwork rede;
   private int pontoMeu = 100;
   private int pontoOponente = 100;
   private int pontoMesa;

   private ActionListener novoJogoActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
         try {
            novo();
         } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
         }
      }
   };

   private ActionListener apostarActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
         try {
            apostar();
         } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
         }
      }
   };

   private ActionListener desistirActionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
		 pontoMeu += pontoMesa;
		 telaJogo.setPontuacao(pontoMeu, pontoOponente);
         desistir();
      }
   };

   public ControladorJogo() throws Exception {
      lerRede();
      maoMinha = new PokerHand();
      maoOponente = new PokerHand();
      telaJogo = new TelaJogo(maoMinha, maoOponente);
      baralho = new Deck();
      novo();
      telaJogo.addBtnNovoActionListener(novoJogoActionListener);
      telaJogo.addBtnApostarActionListener(apostarActionListener);
      telaJogo.addBtnDesistirActionListener(desistirActionListener);
      telaJogo.pack();
      telaJogo.show();
   }

   private void lerRede() throws Exception {
      NetIO io = new NetIO();
      rede = io.load(new File("rede/poker.net"));
      rede.compile();
   }

   private void novo() throws Exception {
   	  pontoMesa = 10;
   	  pontoMeu-=5;
   	  pontoOponente-=5;
	  telaJogo.setPontuacao(pontoMeu, pontoOponente);
   	  
      rede.initialize();
      baralho.shuffle();
      betHand = 1;
      maoMinha.clear();
      maoOponente.clear();
      for (int i = 0; i < 3; i++) {
         maoMinha.addCard(baralho.dealCard());
         maoOponente.addCard(baralho.dealCard());
      }

      maoOponente.setShowHand(true);
      maoMinha.setShowHand(false);
      
      telaJogo.iniciarApostas();
      telaJogo.atualizar();
      telaJogo.setStatus("");
   }

   private void apostar() throws Exception {   	  
      if (betHand > MAXBETHANDS) {
         finalizarJogo();
         return;
      }
      int trocasMinhas = jogadaMinha();
      numTrocas[betHand - 1] = jogadaOponente();
      double prob = calcularProb() * 100;
      telaJogo.setStatus(
         "Eu troquei "
            + trocasMinhas
            + " cartas. "
            + "A probabilidade de minha m�o ser melhor que a sua � de: "
            + prob
            + " %");
      if ((betHand == 1) && (prob < 15)) {
		desistir();
		pontoOponente += pontoMesa;
		telaJogo.setPontuacao(pontoMeu, pontoOponente);
      } else if ((betHand == 2) && (prob < 40)) {
      	desistir();
		pontoOponente += pontoMesa;
		telaJogo.setPontuacao(pontoMeu, pontoOponente);
      } else {
		pontoOponente -=5;
		pontoMeu -= 5;
		pontoMesa += 10;
		telaJogo.setPontuacao(pontoMeu, pontoOponente);	
      	telaJogo.atualizar();
      }

      betHand++;
   }

   private double calcularProb() throws Exception {
      rede.initialize();
      ProbabilisticNode mh = (ProbabilisticNode) rede.getNode("MH");
      ProbabilisticNode fc = (ProbabilisticNode) rede.getNode("FC");
      ProbabilisticNode sc = (ProbabilisticNode) rede.getNode("SC");
      ProbabilisticNode bestHand = (ProbabilisticNode) rede.getNode("Besthand");
      if (betHand >= 1) {
      	System.out.println(numTrocas[0]);
         fc.addFinding(numTrocas[0]);
      }
      if (betHand == 2) {
			System.out.println(numTrocas[1]);
         sc.addFinding(numTrocas[1]);
      }
      switch (maoMinha.getPokerHand()) {
         case PokerHand.NOTHING :
            mh.addFinding(0);
            break;
         case PokerHand.ONEACE :
            mh.addFinding(1);
            break;
         case PokerHand.TWOCONSECUTIVE :
            mh.addFinding(2);
            break;
         case PokerHand.TWOALIKE :
            mh.addFinding(3);
            break;
         case PokerHand.FLUSH :
            mh.addFinding(4);
            break;
         case PokerHand.STRAIGHT :
            mh.addFinding(5);
            break;
         case PokerHand.THREEKIND :
            mh.addFinding(6);
            break;
         case PokerHand.STRAIGHTFLUSH :
            mh.addFinding(7);
            break;
      }
      rede.updateEvidences();

      return bestHand.getMarginalAt(0);
   }

   private int jogadaMinha() {
      switch (maoMinha.getPokerHand()) {
         case PokerHand.NOTHING :
            if (betHand == 1) {
               maoMinha.clear();
            } else {
               maoMinha.removeCard(0);
               maoMinha.removeCard(0);
            }
            break;
         case PokerHand.ONEACE :
            maoMinha.holdAce();
            break;
         case PokerHand.TWOCONSECUTIVE :
            maoMinha.holdTwoConsecutive();
            break;
         case PokerHand.TWOALIKE :
            maoMinha.holdPair();
            break;
      }
      int numCartasTrocadas = 0;
      for (int i = maoMinha.getCardCount(); i < PokerHand.MAXCARDS; i++) {
         maoMinha.addCard(baralho.dealCard());
         numCartasTrocadas++;
      }

      maoMinha.setShowHand(false);
      return numCartasTrocadas;
   }

   /**
    * Retorna o numero de cartas trocadas pelo computador
    * @return numero de cartas trocadas
    */
   private int jogadaOponente() {
      BotaoCarta[] btnsOponente = telaJogo.getBtnCartasOponente();
      int numCartasTrocadas = 0;
      for (int i = 0; i < btnsOponente.length; i++) {
         if (!btnsOponente[i].isSelected()) {
            maoOponente.removeCard(btnsOponente[i].getCarta());
            maoOponente.addCard(baralho.dealCard());
            numCartasTrocadas++;
         }
      }
      maoOponente.setShowHand(true);
      return numCartasTrocadas;
   }

   private void finalizarJogo() {
      telaJogo.acabarApostas();
      maoMinha.setShowHand(true);
      telaJogo.atualizar();
      mostrarGanhador();
   }

   private void desistir() {
      finalizarJogo();
   }

   private void mostrarGanhador() {
      String ganhador;
      if (maoMinha.getPokerHand() > maoOponente.getPokerHand()) {
      	if (betHand > MAXBETHANDS) {
         	ganhador = "VOC� PERDEU!";
         	pontoMeu+=pontoMesa;
			telaJogo.setPontuacao(pontoMeu, pontoOponente);
                      
      	} else {
			ganhador = "VOC� PERDERIA!";
     	}
      } else if (maoMinha.getPokerHand() < maoOponente.getPokerHand()) {
		if (betHand > MAXBETHANDS) {
         	ganhador = "VOC� VENCEU!";
			pontoOponente+=pontoMesa;
			telaJogo.setPontuacao(pontoMeu, pontoOponente);
		} else {
			ganhador = "VOC� VENCERIA!";
		}
      } else {
         ganhador = "EMPATOU!";
      }
      JOptionPane.showMessageDialog(
         telaJogo,
         "Sua m�o: "
            + maoOponente.getPokerHandAsString()
            + "\n"
            + "Minha m�o: "
            + maoMinha.getPokerHandAsString()
            + "\n"
            + ganhador);
   }

   public static void main(String args[]) throws Exception {
      new ControladorJogo();
   }
}
