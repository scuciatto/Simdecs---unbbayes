/*
 * Created on 06/03/2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package tela;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import estrutura.PokerHand;

/**
 * @author Particular
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class TelaJogo extends JFrame {
	private PokerHand maoMinha, maoOponente;
	private JButton btnNovo;
	private JButton btnApostar;
	private JButton btnDesistir;
	private JTextField txtPontoMeu;
	private JTextField txtPontoOponente;
	private PainelMao pnlMaoMinha, pnlMaoOponente;
	
	private JLabel status;

	public TelaJogo(PokerHand maoMinha, PokerHand maoOponente) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("PokerBayes - Powered by UnBBayes");
		this.maoMinha = maoMinha;
		this.maoOponente = maoOponente;
		montarTela();
	}

	public BotaoCarta[] getBtnCartasMinha() {
		return pnlMaoMinha.getBtnCartas();
	}

	public BotaoCarta[] getBtnCartasOponente() {
		return pnlMaoOponente.getBtnCartas();
	}

	private void montarTela() {
		JPanel pnlMenu = new JPanel();
		btnNovo = new JButton("Novo Jogo");
		btnApostar = new JButton("Apostar");
		btnDesistir = new JButton("Desistir");
		txtPontoMeu = new JTextField("100                      ");
		txtPontoOponente = new JTextField("100                      ");
		txtPontoMeu.setEnabled(false);
		txtPontoOponente.setEnabled(false);
		pnlMenu.add(txtPontoMeu);
		pnlMenu.add(btnNovo);
		pnlMenu.add(btnApostar);
		pnlMenu.add(btnDesistir);
		pnlMenu.add(txtPontoOponente);

		JPanel pnlPrincipal = new JPanel();
		pnlMaoOponente = new PainelMao(maoOponente);
		pnlMaoMinha = new PainelMao(maoMinha);
		pnlPrincipal.add(pnlMaoMinha);
		pnlPrincipal.add(pnlMaoOponente);
		
		status = new JLabel();
		
		getContentPane().add(pnlMenu, BorderLayout.NORTH);
		getContentPane().add(pnlPrincipal, BorderLayout.CENTER);
		getContentPane().add(status, BorderLayout.SOUTH);
	}
	
	public void setStatus(String texto) {
		status.setText(texto);
	}

	public void addBtnNovoActionListener(ActionListener al) {
		btnNovo.addActionListener(al);
	}

	public void addBtnApostarActionListener(ActionListener al) {
		btnApostar.addActionListener(al);
	}

	public void addBtnDesistirActionListener(ActionListener al) {
		btnDesistir.addActionListener(al);
	}

	public void atualizar() {
		pnlMaoMinha.atualizar();
		pnlMaoOponente.atualizar();
	}

	public void acabarApostas() {
		btnApostar.setEnabled(false);
		btnDesistir.setEnabled(false);
	}

	public void iniciarApostas() {
		btnApostar.setEnabled(true);
		btnDesistir.setEnabled(true);
	}
	
	public void setPontuacao(int pontoMeu, int pontoOponente) {
		txtPontoMeu.setText(pontoMeu + "                      ");
		txtPontoOponente.setText(pontoOponente + "                      ");
	}
}
