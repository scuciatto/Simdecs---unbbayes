/*
 * Created on 08/03/2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package tela;

import javax.swing.ImageIcon;
import javax.swing.JToggleButton;

import estrutura.Card;

/**
 * @author Particular
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class BotaoCarta extends JToggleButton {
	
	private Card carta;	

	/**
	 * @param icon
	 */
	public BotaoCarta(Card carta) {		
		super(new ImageIcon(carta.getImage()));
		this.carta = carta;		
	}
	/**
	 * @return
	 */
	public Card getCarta() {
		return carta;
	}

}
