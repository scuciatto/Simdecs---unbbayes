/*
 * Created on 06/03/2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package tela;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Image;

/**
 * @author Particular
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ImageCanvas extends Canvas {
	private Image imagem;
	
	public ImageCanvas(Image imagem) {
		this.imagem = imagem;	
		setSize(100, 100);	
	}
	
	/* (non-Javadoc)
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics g) {
		g.drawImage(imagem, 0, 0, getBackground(), this);
	}

	/**
	 * @return
	 */
	public Image getImagem() {
		return imagem;
	}

	/**
	 * @param image
	 */
	public void setImagem(Image image) {
		imagem = image;
		repaint();
	}

}
