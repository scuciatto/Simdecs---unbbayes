package estrutura;
/* 
   A subclass of the Hand class that represents a hand of cards
   in the game of 3 cards Poker.  To the methods inherited form 
   Hand, it adds the method getPokerHand(), which returns the 
   hand that the player has.
*/

public class PokerHand extends Hand {

      public final static int NOTHING = 0, //Nothing of value
      ONEACE = 1, TWOCONSECUTIVE = 2, TWOALIKE = 3, //Two of a kind
      FLUSH = 4, //Three of a Suit
      STRAIGHT = 5, //Three consecutives
      THREEKIND = 6, //Three of a Kind
   	  STRAIGHTFLUSH = 7; //Three consecutives of a suit - but J/Q/K

   public final static int MAXCARDS = 3;

   public int getPokerHand() {
      // Returns the hand for the of 3 cards Poker.

      int hand = PokerHand.NOTHING; // The value computed for the hand.

      if (isStraightFlush()) {
         hand = PokerHand.STRAIGHTFLUSH;
      } else if (isThreeOfAKind()) {
         hand = PokerHand.THREEKIND;
      } else if (isStraight()) {
         hand = PokerHand.STRAIGHT;
      } else if (isFlush()) {
         hand = PokerHand.FLUSH;
      } else if (isPair()) {
         hand = PokerHand.TWOALIKE;
      } else if (isTwoConsecutive()) {
         hand = PokerHand.TWOCONSECUTIVE;
      } else if (isOneAce()) {
         hand = PokerHand.ONEACE;
      }

      return hand;
   } // end getPokerHand()

   public String getPokerHandAsString() {
      switch (getPokerHand()) {
         case PokerHand.STRAIGHTFLUSH :
            return "Straight Flush.";
         case PokerHand.STRAIGHT :
            return "Straight.";
         case PokerHand.FLUSH :
            return "Flush";
         case PokerHand.THREEKIND :
            return "Three of a Kind.";
         case PokerHand.TWOALIKE :
            return "Pair.";
         case PokerHand.TWOCONSECUTIVE :
            return "Two Consecutive";
         case PokerHand.ONEACE :
         	return "One Ace";

         default :
            return "Nothing of value.";
      }
   }
   
   public void holdAce() {
   		if (isOneAce()) {
   			removeCard(1);
			removeCard(1);   	
   		}
   }
   
   public void holdTwoConsecutive() {
   		if (isTwoConsecutive()) {
			if ((getCard(0).getValue() == getCard(1).getValue() + 1)) {
				removeCard(2);				
			} else {
				removeCard(0);
			}
   		}
   }
   
   public void holdPair() {
   		if (isPair()) {
			if (getCard(0).getValue() == getCard(1).getValue()) {
				removeCard(2);				   			   			
			} else if (getCard(1).getValue() == getCard(2).getValue()) {
				removeCard(0);
			} else {
				removeCard(1);
			}
   		}
   }

   private boolean isStraightFlush() {
      return (isStraight() && isFlush());
   }

   private boolean isStraight() {
      return (
         (getCard(0).getValue()  == getCard(1).getValue()-1)
            && (getCard(1).getValue()  == getCard(2).getValue() - 1));
   }

   private boolean isFlush() {
      return (
         (getCard(0).getSuit() == getCard(1).getSuit())
            && (getCard(0).getSuit() == getCard(2).getSuit()));
   }

   private boolean isThreeOfAKind() {
      return (
         (getCard(0).getValue() == getCard(1).getValue())
            && (getCard(0).getValue() == getCard(2).getValue()));
   }

   private boolean isPair() {
      return (
         (getCard(0).getValue() == getCard(1).getValue())
            || (getCard(0).getValue() == getCard(2).getValue())
            || (getCard(1).getValue() == getCard(2).getValue()));
   }

   private boolean isOneAce() {
      return ((getCard(0).getValue() == 1) && (getCard(1).getValue() != 1));
   }

   private boolean isTwoConsecutive() {
      return (
         (getCard(0).getValue() == getCard(1).getValue()-1)
            || (getCard(1).getValue() == getCard(2).getValue()-1))
         && !isStraight();
   }

   /* (non-Javadoc)
    * @see Hand#addCard(Card)
    */
   public void addCard(Card c) {
      if (getCardCount() < PokerHand.MAXCARDS) {
         super.addCard(c);
         sortByValue();
      }
   }

   /* (non-Javadoc)
    * @see estrutura.Hand#removeCard(estrutura.Card)
    */
   public void removeCard(Card c) {
      super.removeCard(c);
      sortByValue();
   }

   /* (non-Javadoc)
    * @see estrutura.Hand#removeCard(int)
    */
   public void removeCard(int position) {
      super.removeCard(position);
      sortByValue();
   }

} // end class BlackjackHand
