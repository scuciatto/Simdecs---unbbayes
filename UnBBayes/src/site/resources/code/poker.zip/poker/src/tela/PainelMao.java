/*
 * Created on 06/03/2004
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package tela;

import java.awt.GridLayout;

import javax.swing.JPanel;

import estrutura.PokerHand;

/**
 * @author Particular
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class PainelMao extends JPanel {
	private PokerHand mao;
	private JPanel pnlCartas;
	private BotaoCarta[] btnCartas;

	public PainelMao(PokerHand mao) {
		this.mao = mao;
		montarPainel();
		atualizar();
	}

	private void montarPainel() {
		pnlCartas = new JPanel();
		pnlCartas.setLayout(new GridLayout(1, mao.getCardCount()));
		add(pnlCartas);
	}

	public void atualizar() {
		pnlCartas.removeAll();
		btnCartas = new BotaoCarta[mao.getCardCount()];
		for (int i = 0; i < mao.getCardCount(); i++) {
			btnCartas[i] = new BotaoCarta(mao.getCard(i)); 	
			pnlCartas.add(btnCartas[i]);				
		}
		pnlCartas.revalidate();
	}
	/**
	 * @return
	 */
	public BotaoCarta[] getBtnCartas() {
		return btnCartas;
	}

}
